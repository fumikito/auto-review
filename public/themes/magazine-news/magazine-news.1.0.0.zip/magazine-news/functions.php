<?php
/**
 * Magazine News functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 */

if ( ! function_exists( 'magazine_news_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function magazine_news_setup() {
	load_theme_textdomain( 'magazine-news', get_template_directory() . '/languages' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_editor_style( get_template_directory_uri() . '/style.css' );

	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'magazine-news' ),
	) );

	add_theme_support( 'html5', array(
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
	) );

	add_theme_support( 'custom-background', apply_filters( 'magazine_news_custom_background_args', array(
		'default-color' => '555555',
		'default-image' => '',
	) ) );
}
endif; // magazine_news_setup
add_action( 'after_setup_theme', 'magazine_news_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function magazine_news_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'magazine_news_content_width', 640 );
}
add_action( 'after_setup_theme', 'magazine_news_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function magazine_news_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'magazine-news' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'magazine_news_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function magazine_news_scripts() {

	wp_enqueue_script( 'seos-magazine-magazine-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );

	wp_enqueue_script( 'seos-magazine-magazine-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	wp_enqueue_style( 'seos-magazine-dashicons-style', get_stylesheet_uri(), array('dashicons'), '1.0' );
	
	wp_enqueue_style( 'seos-magazine-fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css' );
	
	wp_enqueue_style( 'seos-magazine-font-oswald', '//fonts.googleapis.com/css?family=Oswald:400,300,700', false, 1.0, 'screen' );
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'magazine_news_scripts' );

	require get_template_directory() . '/inc/custom-header.php';
	require get_template_directory() . '/inc/template-tags.php';
	require get_template_directory() . '/inc/extras.php';
	require get_template_directory() . '/inc/customizer.php';
	require get_template_directory() . '/inc/jetpack.php';

/*********************************************************************************************************
* Search Form
**********************************************************************************************************/

		function magazine_news_search_form( $form ) {
			$form = '<form role="search" method="get" class="search-form" action="' . esc_url(home_url( '/' )) . '" >
			<div><label class="screen-reader-text" for="s">' . __( 'Search', 'magazine-news') . '</label>
			<input type="search" class="search-field" placeholder="'. esc_attr_x( 'Search ...', '', 'magazine-news' ) . '" value="' . get_search_query() . '" name="s" id="s" />
			<input type="submit" class="search-submit" value="'. esc_attr__( 'GO', 'magazine-news' ) .'" />
			</div>
			</form>';
			return $form;
		}

		add_filter( 'get_search_form', 'magazine_news_search_form' );
	
/*********************************************************************************************************
* Pagination. 
**********************************************************************************************************/

		add_filter('wp_link_pages_args','magazine_news_add_next_and_number');

		function magazine_news_add_next_and_number($args){
			if($args['next_or_number'] == 'next_and_number'){
				global $page, $numpages, $multipage, $more, $pagenow;
				$args['next_or_number'] = 'number';
				$prev = '';
				$next = '';
				if ( $multipage ) {
					if ( $more ) {
						$i = $page - 1;
						if ( $i && $more ) {
							$prev .= _wp_link_page($i);
							$prev .= $args['link_before']. $args['previouspagelink'] . $args['link_after'] . '</a>';
						}
						$i = $page + 1;
						if ( $i <= $numpages && $more ) {
							$next .= _wp_link_page($i);
							$next .= $args['link_before']. $args['nextpagelink'] . $args['link_after'] . '</a>';
						}
					}
				}
				$args['before'] = $args['before'].$prev;
				$args['after'] = $next.$args['after'];    
			}
			return $args;
		}

/***********************************************************************************
 * Magazine News How To Use
***********************************************************************************/

		function magazine_news_support($wp_customize){
			class magazine_news_Customize extends WP_Customize_Control {
				public function render_content() { ?>
				<div class="seos-magazine-info"> 
					<button class="button media-button button-primary button-large media-button-select">
						<a href="<?php echo esc_url( 'http://seosthemes.com/magazine-news/' ); ?>" title="<?php esc_attr_e( 'Magazine News Read More', 'magazine-news' ); ?>" target="_blank">
						<?php _e( 'Magazine News how to use Premium', 'magazine-news' ); ?>
						</a>
					</button>
				</div>
				<?php
				}
			}
		}
		add_action('customize_register', 'magazine_news_support');

		function magazine_news_customize_styles( $input ) { ?>
			<style type="text/css">
				#customize-theme-controls #accordion-section-magazine_news_buy_section .accordion-section-title,
				#customize-theme-controls #accordion-section-magazine_news_buy_section > .accordion-section-title {
					background: #555555;
					color: #FFFFFF;
				}

				.seos-magazine-info button a {
					color: #FFFFFF;
				}	
			</style>
		<?php }
		
		add_action( 'customize_controls_print_styles', 'magazine_news_customize_styles');

		if ( ! function_exists( 'magazine_news_buy' ) ) :
			function magazine_news_buy( $wp_customize ) {
			$wp_customize->add_section( 'magazine_news_buy_section', array(
				'title'			=> __('Buy Premium', 'magazine-news'),
				'description'	=> __('	Learn more about Magazine News Premium. ','magazine-news'),
				'priority'		=> 1,
			));
			$wp_customize->add_setting( 'magazine_news_setting', array(
				'capability'		=> 'edit_theme_options',
				'sanitize_callback'	=> 'wp_filter_nohtml_kses',
			));
			$wp_customize->add_control(
				new magazine_news_Customize(
					$wp_customize,'magazine_news_setting', array(
						'label'		=> __('Buy Premium', 'magazine-news'),
						'section'	=> 'magazine_news_buy_section',
						'settings'	=> 'magazine_news_setting',
					)
				)
			);
		}
		endif;
		 
		add_action('customize_register', 'magazine_news_buy');	
