Magazine News WordPress Theme, Copyright 2016 SEOS - Tsvetomir Tsvetanov
Magazine News is distributed under the terms of the GNU GPL2

=== Magazine News ===

Theme Name: Magazine News
Theme URI: http://seosthemes.com/magazine-news/
Author: SEOS
Author URI: http://seosthemes.com/
Description: Magazine News is a modern responsive WordPress theme. The Magazine News theme is excellent for a news, newspaper, magazine, publishing or other editorial websites.To learn more about the theme please go to the theme uri and read the documentation.
Version: 1.0.8
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: magazine-news
Tags: custom-menu, custom-background, custom-colors, custom-header, featured-images, featured-image-header, left-sidebar, responsive-layout, sticky-post, translation-ready, threaded-comments, white


Requires at least: 4.4.2
Tested up to: 4.4.2
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Magazine News is a modern responsive WordPress theme. The Magazine News theme is excellent for a news, newspaper, magazine, publishing or other editorial websites.To learn more about the theme please go to the theme uri and read the documentation.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Seos  Magazine includes support for Infinite Scroll in Jetpack.

== Changelog ==

= 1.0 - April 01 2016 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

= Licenses =
 Magazine News WordPress Theme bundles the following third-party resources:

 * Images - https://www.pexels.com/search/new%20york/ - CC0 1.0 License
 * Google Fonts - https://www.google.com/fonts/specimen/Oswald - SIL Open Font License, 1.1
 * Font Awesome - http://opensource.org/licenses/mit-license.html - MIT License
 
 Unless otherwise specified, all the theme files, scripts and images
 are licensed under GNU General Public License version 2.
