<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">
		    <?php _e('All rights reserved', 'magazine-news'); ?>  &copy; <?php bloginfo('name'); ?>	
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'magazine-news' ) ); ?>"><?php printf( __( 'Powered by %s', 'magazine-news' ), 'WordPress' ); ?></a>			
			<a title="<?php _e('Seos free wordpress themes', 'magazine-news'); ?>" href="<?php echo esc_url(__('http://seosthemes.com/', 'magazine-news')); ?>" rel="designer" target="_blank"><?php _e('Theme by SEOS', 'magazine-news'); ?></a>	
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php wp_footer(); ?>

</body>
</html>
