<?php
/*
 * Comments template
 */

do_action( 'monday_before_comments' );

if (
	post_password_required()
	|| ( ! have_comments() && ! comments_open() )
) {
	return;
}

?>
<a id="comments"></a>
<section class="comments">
<?php

if ( have_comments() ) {
	
	$comments_number = get_comments_number();
	
	/* translators: 1: number of comments, 2: post title */
	$comments_title = sprintf(
		_nx(
			'One reply on &ldquo;%2$s&rdquo;',
			'%1$s replies on &ldquo;%2$s&rdquo;',
			$comments_number,
			'comments title',
			'monday'
		),
		$comments_number,
		get_the_title()
	);

	printf(
		'<h3 class="comments-title">%s</h3>',
		apply_filters( 'monday_comments_title', $comments_title )
	);
	
	echo '<ul class="comments-list">';
	wp_list_comments( apply_filters( 'monday_wp_list_comments_args', array(
		'callback' 			=> 'monday_comment_callback',
		'avatar_size'		=> 64
	) ) );
	echo '</ul>';
	
	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
?>

	<p class="no-comments"><?php _e( 'Comments are closed.', 'monday' ); ?></p>
	
<?php
	endif;

	if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) {
		
		echo '<nav class="navigation comment-navigation">';	
		paginate_comments_links( apply_filters( 'monday_paginate_comments_links_args', array() ) );
		echo '</nav>';
		
	}

}

comment_form( apply_filters( 'monday_comment_form_args', array(
	'title_reply'       => __( 'Leave a reply', 'monday' ),
	'title_reply_to'    => __( 'Leave a reply to %s', 'monday' ),
	'cancel_reply_link' => __( 'Cancel reply', 'monday' ),
	'label_submit'      => __( 'Post comment', 'monday' ),
) ) );

?>
</section>
<?php

do_action( 'monday_after_comments' );
