<?php
/*
 * Theme functions and filters
 */


//* Theme support

add_action( 'after_setup_theme', 'monday_support' );

if ( ! function_exists( 'monday_support' ) ) {
function monday_support() {

	// This theme supports html5 markup
	add_theme_support( 'html5', array(
		'gallery',
		'caption',
		'comment-form',
		'search-form'
	) );
	
	// This theme supports Automatic Feed Links
	add_theme_support( 'automatic-feed-links' );

	// This theme supports the title tag
	add_theme_support( 'title-tag' );
	
	// This theme uses featured images (post thumbnails)
	add_theme_support( 'post-thumbnails' );

	// Support for header image
	add_theme_support( 'custom-header', array(
		'width' 			=> 1152,
		'flex-width' 	=> true,
		'height' 			=> 120,
		'flex-height' => true,
	) );
	
	// Support for custom background
	add_theme_support( 'custom-background', array(
    'default-color'	=> '',
	) );
	
	// Support for site logo.
	add_theme_support( 'custom-logo', array(
		'width' 			=> 300,
		'height' 			=> 100,
		'flex-width' 	=> true,
		'flex-height' => true,
		'header-text' => array( 'header-text' ),
	) );
	
	// Pages can have excerpt
	add_post_type_support( 'page', array( 'excerpt' ) );
	
	// Support for editor styles
	add_editor_style();
	
}
}

//* Theme setup

add_action( 'after_setup_theme', 'monday_setup' );

if ( ! function_exists( 'monday_setup' ) ) {
function monday_setup() {

	// Make the theme available for translation
	load_theme_textdomain( 'monday', get_template_directory() . '/lang' );

	// Set the image sizes used by this theme
	set_post_thumbnail_size( 1152, 1152 );
	add_image_size( 'tablet', 832, 832 );
	add_image_size( 'theme-logo', 300, 100 );

	// Remove the default gallery style
	add_filter( 'use_default_gallery_style', '__return_false' );

}
}

//* Nav menus

add_action( 'after_setup_theme', 'monday_register_nav_menus' );

if ( ! function_exists( 'monday_register_nav_menus' ) ) {
function monday_register_nav_menus() {
	
	// Register the nav menus supported by this theme
	register_nav_menus( apply_filters( 'register_nav_menus', 
		array(
			'primary' 	=> __( 'Primary', 'monday' ),
			'secondary' => __( 'Secondary', 'monday' ),
			'header' 		=> __( 'Header', 'monday' ),
			'footer' 		=> __( 'Footer', 'monday' ),
		)
	) );
}
}

//* Widget areas

add_action( 'widgets_init', 'monday_register_widget_areas' );

if ( ! function_exists( 'monday_register_widget_areas' ) ) {
function monday_register_widget_areas() {
	
	// Available widget areas
	$monday_widget_areas = apply_filters( 'monday_widget_areas', array(
		'sidebar' 	=> __( 'Sidebar', 'monday' ),
		'header' 		=> __( 'Header widgets', 'monday' ),
		'footer' 		=> __( 'Footer widgets', 'monday' ),
		'widgets' 	=> __( 'Utility widgets', 'monday' ),
	) );
	
	// Register each widget area
	foreach ( $monday_widget_areas as $id => $name ) {
		
		register_sidebar( array(
			'id'            	=> $id,
			'name'          	=> $name,
			'description'   	=> '',
			'before_widget' 	=> '<div class="widget %2$s %1$s">',
			'after_widget'  	=> '</div>',
			'before_title'  	=> '<h4 class="widget-title">',
			'after_title'   	=> '</h4>',
		) );
		
	}
	
}
}

//* Styles and scripts

add_action( 'wp_enqueue_scripts', 'monday_enqueue_styles' );

if ( ! function_exists( 'monday_enqueue_styles' ) ) {
function monday_enqueue_styles() {

	// Theme stylesheet
	wp_enqueue_style( 'monday', get_stylesheet_uri() );
	
	// Theme scripts
	wp_register_script( 'monday', get_template_directory_uri() . '/js/script.js', array(), false, true );
	
	// Comment reply
	if ( is_singular() && comments_open() ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
}

//* Content width

if ( ! isset( $content_width ) ) {
	$content_width = apply_filters( 'monday_content_width', 800 );
}

//* Required files

require_once 'inc/template.php';

require_once 'inc/general.php';

require_once 'inc/entry.php';

require_once 'inc/archive.php';

require_once 'inc/jetpack.php';

require_once 'inc/admin.php';

require_once 'inc/customizer.php';


//* Set up actions and filters

add_filter( 'nav_menu_item_id', '__return_false' );
add_filter( 'monday_footer_text', 'wpautop' );


