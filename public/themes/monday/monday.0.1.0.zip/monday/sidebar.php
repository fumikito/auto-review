<?php
/*
 * Default sidebar template
 */

if ( ! apply_filters( 'monday_show_sidebar', is_active_sidebar( 'sidebar' ) ) ) {
	return;
}

?>
<aside id="sidebar" class="sidebar">
<?php
	dynamic_sidebar( 'sidebar' );
?>
</aside>