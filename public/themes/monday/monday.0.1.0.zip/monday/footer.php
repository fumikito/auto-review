<?php
/*
 * Footer template
 */

?>

<?php
	do_action( 'monday_before_footer' );
?>

<footer class="site-footer">

<?php
	get_template_part( 'components/breadcrumbs' );
	get_template_part( 'components/footer-widgets' );
?>

<div id="footer" role="contentinfo">
<?php
	get_template_part( 'components/footer-nav' );
	get_template_part( 'components/footer-text' );

?>
</div>

</footer>

<?php
	get_template_part( 'components/foot' );