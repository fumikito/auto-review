<?php
/*
 * Template Name: Full width
 *
 * Full width page template
 */

add_filter( 'monday_show_sidebar', '__return_false', 20 );

get_template_part( 'index' );