<?php
/*
 * General functions and filters
 */

/* Theme callback function for wp_list_comments */

function monday_comment_callback( $comment, $args, $depth ) {
	
	// We need to use include so we can access the arguments
	include( locate_template( array(
		'components/comment-' . get_comment_type() . '.php',
		'components/comment.php'
	) ) );
	
}