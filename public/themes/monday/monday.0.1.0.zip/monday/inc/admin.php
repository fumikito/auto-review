<?php
/*
 * Admin functions and filters
 */