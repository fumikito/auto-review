<?php
/*
 * Theme template tags
 */
