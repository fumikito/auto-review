<?php
/*
 * Entry functions and filters
 */
