<?php
/*
 * Archive functions and filters
 */