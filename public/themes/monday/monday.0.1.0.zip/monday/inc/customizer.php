<?php
/*
 * Customizer functions and filters
 */


function monday_customize_register( $wp_customize ) {
	
	// Sections
	
	// Settings and controls
	
	$wp_customize->add_setting( 'footer_text' , array(
		'default' 					=> '',
	  'sanitize_callback' => 'esc_html',
	) );
	
	$wp_customize->add_control( 'footer_text', array(
	  'priority' 					=> 40,
	  'section' 					=> 'title_tagline',
	  'label' 						=> __( 'Footer text', 'monday' ),
	) );
	
}

add_action( 'customize_register', 'monday_customize_register' );
