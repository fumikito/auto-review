<?php
/*
 * Main template
 */

get_header();

?>

<div class="<?php echo apply_filters( 'monday_content_wrap_class', 'content-wrap' ); ?>">
<a id="content"></a><?php // Mark main content of the page for skip link ?>

<main class="main">

<?php

do_action( 'monday_main_top' );

if ( is_archive() || is_search() || is_home() ) {
	get_template_part( 'components/page-header' );
}

get_template_part( 'components/loop' );

if ( apply_filters( 'monday_show_author_bio', is_singular( array( 'post' ) ) && is_multi_author() ) )
	get_template_part( 'components/author-bio' );

if ( is_singular() )
	get_template_part( 'components/navigation' );

if ( ! is_singular() )
	get_template_part( 'components/pagination' );

if ( is_singular() )
	comments_template();

do_action( 'monday_main_bottom' );

?>

</main>

<?php

get_sidebar();

?>

</div><?php //.content-wrap ?>

<?php

get_footer();