<?php
/*
 * Footer widgets template
 */

if ( ! is_active_sidebar( 'footer' ) )
	return;

?>
<aside class="footer-widgets">
<div class="widgets">
<?php
	dynamic_sidebar( 'footer' );
?>
</div>
</aside>