<?php
/*
 * No content template
 */

if ( is_404() ) {
	$entry_title = __( 'Page not found', 'monday' );
	
} elseif ( is_search() ) {
	$entry_title = __( 'Nothing found', 'monday' );

} else {
	$entry_title = __( 'Nothing to show', 'monday' );
	
}

if ( is_404() ) {
	$entry_excerpt = __( 'The page you are trying to access cannot be found. The link may be broken, expired, or the content may have been removed.', 'monday' );
	
} elseif ( is_search() ) {
	$entry_excerpt = __( "We didn't find anything to match you search query. You can try again using similar words, or visit the homepage and start the browsing from there.", 'monday' );

} else {
	$entry_excerpt = __( "There's nothing to see here, move along.", 'monday' );
	
}

?>
<article class="hentry nocontent">

<header>
	<h1 class="entry-title"><?php echo apply_filters( 'the_title', $entry_title ); ?></h1>
</header>
	
<div class="entry-excerpt">
<?php
	echo apply_filters( 'the_content', $entry_excerpt );
?>
</div>

</article>

<?php
	get_template_part( 'components/widgets', 'none' );
?>