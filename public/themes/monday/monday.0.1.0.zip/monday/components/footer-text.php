<?php
/*
 * Site colophon
 */

// Provide a default footer text

if ( $footer_text_mod = get_theme_mod( 'footer_text', false ) ) {
	$footer_text = $footer_text_mod;
	
} else {
	$footer_text = sprintf( __( '&copy; %s', 'monday' ), get_bloginfo( 'name', 'display' ) );
	
}

if ( ! $footer_text ) {
	return;
}

?>
<div class="footer-text">
<?php
	echo apply_filters( 'monday_footer_text', $footer_text );
?>
</div>