<?php
/*
 * Skip links template
 */

?><section class="skip-links">

<h4 class="screen-reader-text"><?php _e( 'Skip links', 'monday' ); ?></h4>
<a href="#content" class="screen-reader-text"><?php _e( 'Skip to content', 'monday' ); ?></a>
<a href="#nav" class="screen-reader-text"><?php _e( 'Skip to navigation', 'monday' ); ?></a>
<?php
	if ( apply_filters( 'monday_show_sidebar', is_active_sidebar( 'sidebar' ) ) ) :
?>
<a href="#sidebar" class="screen-reader-text"><?php _e( 'Skip to sidebar', 'monday' ); ?></a>
<?php
	endif;	
?>

</section>
