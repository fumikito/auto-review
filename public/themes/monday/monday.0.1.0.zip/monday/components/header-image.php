<?php
/*
 * Header image
 */

if ( get_header_image() ) {

	$attachment_id = get_custom_header()->attachment_id;
	$header_img = wp_get_attachment_image( $attachment_id, 'full', false );
	
	printf(
		'<a href="%s" class="header-image">%s</a>',
		esc_url( apply_filters( 'monday_header_image_link_url', home_url() ) ),
		$header_img
	);

}