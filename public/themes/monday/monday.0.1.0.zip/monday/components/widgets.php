<?php
/*
 * Utility widgets template
 */

if ( ! is_active_sidebar( 'widgets' ) )
	return;

?>
<aside class="utility-widgets">
<?php
	dynamic_sidebar( 'widgets' );
?>
</aside>