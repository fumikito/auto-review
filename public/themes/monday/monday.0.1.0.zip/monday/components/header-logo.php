<?php
/*
 * Header logo template
 */

if (  ! has_custom_logo() )
	return;

?>

<div class="header-logo">
<?php
	the_custom_logo();
?>
</div>