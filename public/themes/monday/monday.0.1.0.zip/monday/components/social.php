<?php
/*
 * Entry social template
 */

?><section class="entry-social"><p>
<?php
	
if ( post_type_supports( get_post_type(), 'comments' ) && comments_open() ) {
			
	$comments_number = get_comments_number();
	
	/* translators: 1: number of comments, 2: post title */
	$comments_link_title = sprintf(
		_nx(
			'1 reply',
			'%1$s replies',
			$comments_number,
			'comments link title',
			'monday'
		),
		$comments_number
	);

	// Comments link
	printf(
		'<a class="comments-link" href="%s">%s</a>',
		get_comments_link(),
		apply_filters( 'monday_comments_link_title', $comments_link_title )
	);

}
	
// Share label

printf( '<span class="share-label">%s</span>', __( 'Share:', 'monday' ) );

// Facebook share
printf(
	'<a class="facebook-share" href="http://www.facebook.com/sharer.php?u=%1$s" 
	onclick="popUp=window.open(\'http://www.facebook.com/share.php?u=%1$s&title=%2$s\', \'popupwindow\', \'scrollbars=yes,width=600,height=400\');popUp.focus();return false" title="%3$s"><span>%4$s</span></a>',
	urlencode( get_permalink() ),
	urlencode( get_the_title() ),
	__( 'Share on Facebook', 'monday' ),
	__( 'Facebook', 'monday' )
);

// Twitter tweet
printf(
	'<a class="twitter-share" href="http://twitter.com/share?text=%1$s&url=%2$s" 
	onclick="popUp=window.open(\'http://twitter.com/home?status=%1$s %2$s\', \'popupwindow\', \'scrollbars=yes,width=600,height=320\');popUp.focus();return false" title="%3$s"><span>%4$s</span></a>',
	urlencode( get_the_title() ),
	urlencode( get_permalink() ),
	__( 'Share on Twitter', 'monday' ),
	__( 'Twitter', 'monday' )
);

// Google+ Plus
printf(
	'<a class="google-share" href="https://plus.google.com/share?url=%1$s&t=%2$s"
	onclick="popUp=window.open(\'https://plus.google.com/share?url=%1$s\', \'popupwindow\', \'scrollbars=yes,width=510,height=410\');popUp.focus();return false" title="%3$s"><span>%4$s</span></a>',
	urlencode( get_permalink() ),
	urlencode( get_the_title() ),
	__( 'Share on Google+', 'monday' ),
	__( 'Google+', 'monday' )
);

// Pinterest
printf(
	'<a class="pinterest-share" href="http://pinterest.com/pin/create/button/?url=%1$s&media=%2$s"
	onclick="return !window.open(this.href, \'%4$s\', \'width=500, height=500\')" title="%3$s"><span>%4$s</span></a>',
	urlencode( get_permalink() ),
	urlencode( get_the_post_thumbnail() ),
	__( 'Pin on Pinterest', 'monday' ),
	__( 'Pinterest', 'monday' )
);

// Reddit
printf(
	'<a class="reddit-share" href="http://www.reddit.com/submit?url=%1$s&title=%2$s"
	onclick="return !window.open(this.href, \'%4$s\', \'width=500, height=500\')" title="%3$s"><span>%4$s</span></a>',
	urlencode( get_permalink() ),
	urlencode( get_the_title() ),
	__( 'Share on Reddit', 'monday' ),
	__( 'Reddit', 'monday' )
);

// LinkedIn
printf(
	'<a class="linkedin-share" href="http://www.linkedin.com/shareArticle?mini=true&url=%1$s&title=%2$s&source=%1$s"
	onclick="return !window.open(this.href, \'%4$s\', \'width=500, height=500\')" title="%3$s"><span>%4$s</span></a>',
	urlencode( get_permalink() ),
	urlencode( get_the_title() ),
	__( 'Share on LinkedIn', 'monday' ),
	__( 'LinkedIn', 'monday' )
);


?>
</p></section>