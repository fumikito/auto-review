<?php
/*
 * Breadcrumbs template
 */

do_action( 'monday_before_breadcrumbs' );

$prefix = sprintf( '<span class="prefix">%s</span>', __( 'You are here: ', 'monday' ) );

if ( function_exists( 'is_bbpress' ) && is_bbpress() ) {
	// bbPress support
	bbp_breadcrumb( array(
		'before' 	=> '<section class="breadcrumbs"><p>' . $prefix,
		'after' 	=> '</p></section>',
	) );
	
} elseif ( function_exists( 'yoast_breadcrumb' ) ) {
	
	// Yoast SEO support
	yoast_breadcrumb( '<section class="breadcrumbs"><p>' . $prefix, '</p></section>' );
	
} elseif ( function_exists( 'bcn_display' ) ) {
	
	// Breadcrumb NavXT support
	echo '<section class="breadcrumbs" typeof="BreadcrumbList" vocab="http://schema.org/"><p>' . $prefix;
	bcn_display();
  echo '</p></section>';

} else {
	return;
}

do_action( 'monday_after_breadcrumbs' );
