<?php
/*
 * Pagination template
 */

global $wp_query;
if ( $wp_query->max_num_pages <= 1 )
  return;

?>
<nav class="pagination"><p>
<?php
	echo paginate_links( array(
		'prev_text'          => __( '&laquo; Previous', 'monday' ),
		'next_text'          => __( 'Next &raquo;', 'monday' ),
		'before_page_number' => '<span class="screen-reader-text">' . __( 'Page', 'monday' ) . ' </span>'
	) );
?>
</p></nav>