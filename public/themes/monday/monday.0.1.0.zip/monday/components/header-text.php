<?php
/*
 * Header text template
 */

// Check if we need to show the header text
if ( ! display_header_text() || has_custom_logo() )
	return;

$header_textcolor = '';
if ( get_header_textcolor() ) {
	$header_textcolor = sprintf( ' style="color: #%s;"', get_header_textcolor() );
}

?>

<div class="header-text"<?php echo $header_textcolor; ?>>
	<h1 class="site-title"><a href="<?php echo home_url(); ?>"><?php bloginfo('name', 'display'); ?></a></h1>
	<p class="site-tagline"><?php bloginfo('description', 'display'); ?></p>
</div>