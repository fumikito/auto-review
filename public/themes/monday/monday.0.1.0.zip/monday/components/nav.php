<?php
/*
 * Primary nav menu template
 */

do_action( 'monday_nav_before' );

wp_nav_menu( apply_filters( 'monday_nav_args', array(
	'theme_location' 	=> 'primary',
	'container' 			=> 'nav',
	'container_class'	=> 'nav primary',
	'container_id' 		=> 'nav',
	'menu_class' 			=> 'nav primary',
	'menu_id' 				=> 'nav',
	'fallback_cb' 		=> 'wp_page_menu',
) ) );

do_action( 'monday_nav_after' );