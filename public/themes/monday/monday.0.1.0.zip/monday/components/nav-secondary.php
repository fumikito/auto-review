<?php
/*
 * Secondary nav menu template
 */

do_action( 'monday_nav_before' );

wp_nav_menu( apply_filters( 'monday_nav_args', array(
	'theme_location' 	=> 'secondary',
	'container' 			=> 'nav',
	'container_class'	=> 'nav secondary',
	'menu_class' 			=> 'nav secondary',
	'fallback_cb' 		=> '',
) ) );

do_action( 'monday_nav_after' );