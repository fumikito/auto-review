<?php
/*
 * Author bio template
 */

?>

<section class="author-bio">
	<div class="author-avatar">
	<?php
		$author_bio_avatar_size = apply_filters( 'monday_author_bio_avatar_size', 96 );
		echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
	?>
	</div>

	<div class="author-description">
		<h4 class="author-title">
			<span class="author-prefix"><?php _ex( 'Author: ', 'author bio title', 'monday' ); ?></span>
			<?php echo get_the_author(); ?>
		</h4>

		<div class="author-text">
		<?php
			echo apply_filters( 'monday_author_bio_description', get_the_author_meta( 'description' ) );
		?>
		</div>
		
		<p class="author-links">
		<?php

			// Link to the reply form
			if ( is_singular() && ! post_password_required() && ( comments_open() ) ) {
				
				printf( '<a class="reply-link" href="%s#respond">%s</a>',
					get_permalink(),
					sprintf(
						__( 'Leave a comment<span class="screen-reader-text"> on %s</span>', 'monday' ),
						get_the_title()
					)
				);
				
			}
			
			// Link to author archives
			if ( ! is_author() ) {
				
				printf( '<a class="author-link" href="%s">%s</a>',
					esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
					sprintf( __( 'View all posts<span class="screen-reader-text"> by %s</span>', 'monday' ), get_the_author() )
				);
				
			}
			
			// Author RSS feed
			if ( false && is_author() ) {
				
				printf( '<a class="author-rss" href="%s/feed" target="_blank">%s</a>',
					get_the_author(),
					__( 'Author RSS', 'monday' )
				);
			
			}
			
			// Link to author website
			if ( $author_url = get_the_author_meta( 'user_url' ) ) {
				
				printf( '<a class="author-url" href="%s" target="_blank">%s</a>',
					esc_url( $author_url ),
					sprintf(
						__( 'Website<span class="screen-reader-text"> of %s</span>', 'monday' ),
						get_the_author()
					)
				);
				
			}
			
			// Edit author link
			if ( $edit_author_link = get_edit_user_link( get_the_author_meta( 'ID' ) ) ) {
				
				printf( '<a class="author-edit-link" href="%s">%s</a>',
					esc_url( $edit_author_link ),
					__( '(Edit this)', 'monday' )
				);
				
			}
			
		?>
		</p>
	</div>
</section>