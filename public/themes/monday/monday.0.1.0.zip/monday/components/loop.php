<?php
/*
 * Default loop template
 */

do_action( 'monday_before_loop' );

// Check for content
if ( have_posts() ) :

do_action( 'monday_before_loop_while' );
echo '<section class="feed">';

// Start the loop.
while ( have_posts() ) : the_post();

	// Show the content
	
	do_action( 'monday_before_entry' );
	
	get_template_part(
		'components/content',
		apply_filters( 'monday_loop_content_name', get_post_type() )
	);
	
	do_action( 'monday_after_entry' );

endwhile;

echo '</section>';
do_action( 'monday_after_loop_while' );

else :

	// No content
	
	get_template_part(
		apply_filters( 'monday_loop_content_name_none', 'components/content-none' )
	);

endif;

do_action( 'monday_after_loop' );