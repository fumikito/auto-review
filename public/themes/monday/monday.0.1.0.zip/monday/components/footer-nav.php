<?php
/*
 * Footer nav menu template
 */

wp_nav_menu( apply_filters( 'monday_footer_nav_args', array(
	'theme_location' 	=> 'footer',
	'container' 			=> 'nav',
	'container_class'	=> 'footer-nav',
	'fallback_cb' 		=> '',
	'depth' 					=> 1,
) ) );
