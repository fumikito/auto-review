<?php
/*
 * Header nav menu template
 */

wp_nav_menu( apply_filters( 'monday_header_nav_args', array(
	'theme_location' 	=> 'header',
	'container' 			=> 'nav',
	'container_class'	=> 'header-nav',
	'fallback_cb' 		=> '',
	'depth' 					=> 2,
) ) );
