<?php
/*
 * Header widgets template
 */

if ( ! is_active_sidebar( 'header' ) )
	return;

?>

<aside class="header-widgets">
<div class="widgets">
<?php
	dynamic_sidebar( 'header' );
?>
</div>
</aside>