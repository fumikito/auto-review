<?php
/*
 * Navigation template
 */

global $post;

if ( is_singular( 'attachment' ) && $post->post_parent ) {
	
	// Parent post link
	the_post_navigation( array(
		'screen_reader_text' => __( 'Post navigation', 'monday' ),
		'prev_text' => '<span class="meta-nav">' . _x( 'Published in:', 'Parent post link', 'monday' ) . '</span> <span class="post-title">%title</span>',
	) );
	
} elseif ( is_singular( 'post' ) ) {
	
	// Previous/next post links
	the_post_navigation( array(
		'screen_reader_text' => __( 'Post navigation', 'monday' ),
		'next_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Next:', 'monday' ) . '</span> ' .
			'<span class="screen-reader-text">' . __( 'Next post:', 'monday' ) . '</span> ' .
			'<span class="post-title">%title</span>',
		'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __( 'Previous:', 'monday' ) . '</span> ' .
			'<span class="screen-reader-text">' . __( 'Previous post:', 'monday' ) . '</span> ' .
			'<span class="post-title">%title</span>',
	) );
	
}

?>