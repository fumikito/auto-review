<?php
/*
 * Page header template
 */

do_action( 'monday_before_page_header' );

$page_title = '';

if ( is_home() ) {
	
  if ( get_option( 'page_for_posts' ) ) {
    $page_title = get_the_title( get_option('page_for_posts') );
    
  } else {
    $page_title = __( 'Latest posts', 'monday' );
    
  }
  
} elseif ( is_archive() ) {
  $page_title = get_the_archive_title();
  
} elseif ( is_search() ) {
  $page_title = sprintf(
  	__( 'Search results for: %s', 'monday' ),
  	'<span class="keywords">' . get_search_query() . '</span>'
  );
  
} elseif ( is_404() ) {
  $page_title = __( 'Page not found', 'monday' );
  
} else {
  $page_title = get_the_title();
 
}

$page_description = get_the_archive_description();


if ( $page_title || $page_description ) :

?>
<header class="page-header">
<?php
	
	// The page title
	if ( $page_title ) {
		printf( '<h4 class="page-title">%s</h4>', $page_title );
	}
	
	// The page description
	if ( $page_description ) {
		printf( '<div class="page-description">%s</div>', $page_description );
	}
	
	// The edit term edit link
	if ( is_tax() || is_category() || is_tag() ) {
		edit_term_link( __( '(Edit this)', 'monday' ), '<p class="edit-term">', '</p>' );
	}
	
?>
</header>

<?php

endif;
	
do_action( 'monday_after_page_header' );

if ( is_author() ) 
	get_template_part( 'components/author-bio' );
	
?>