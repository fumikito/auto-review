<?php
/*
 * Foot template
 */

do_action( 'monday_after' );
wp_footer();

?>

</body>
</html>