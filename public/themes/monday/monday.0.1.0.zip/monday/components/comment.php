<?php
/*
 * Comment template
 */

$GLOBALS['comment'] = $comment;

switch ( $comment->comment_type ) :
	case 'pingback' :
	case 'trackback' :
	// Display trackbacks differently than normal comments.
?>
<li <?php comment_class(); ?>>
	<article id="comment-<?php comment_ID(); ?>" class="pingback">
		<p><?php _e( 'Pingback:', 'monday' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( __( '(Edit)', 'monday' ), '<span class="edit-link">', '</span>' ); ?></p>
	</article>
<?php
		break;
	default :
	// Proceed with normal comments.
	global $post;
?>
<li <?php comment_class(); ?>>
	<article id="comment-<?php comment_ID(); ?>" class="comment">
		<header class="comment-meta comment-author vcard">
			<?php
				echo get_avatar( $comment, 44 );
				printf( '<b class="fn">%s</b>',
					get_comment_author_link()
				);
				
				// Show a membership label for the commenter
				if ( $comment->user_id > 0 ) {
					echo ( $comment->user_id === $post->post_author ) ? '<span class="author-label">' . __( 'Author', 'monday' ) . '</span>' : '<span class="author-label">' . __( 'User', 'monday' ) . '</span>';
					
				} else {
					echo '<span class="author-label">' . __( 'Guest', 'monday' ) . '</span>';
					
				}
				
				printf( '<a href="%1$s" class="date"><time datetime="%2$s">%3$s</time></a>',
					esc_url( get_comment_link( $comment->comment_ID ) ),
					get_comment_time( 'c' ),
					/* translators: 1: date, 2: time */
					sprintf( __( '%1$s at %2$s', 'monday' ), get_comment_date(), get_comment_time() )
				);
			?>
		</header>

		<?php if ( '0' == $comment->comment_approved ) : ?>
			<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'monday' ); ?></p>
		<?php endif; ?>

		<section class="comment-content comment">
			<?php comment_text(); ?>
			<?php edit_comment_link( __( '(Edit comment)', 'monday' ), '<p class="edit-link">', '</p>' ); ?>
		</section>

			<?php
				comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply', 'monday' ) ) ) );
			?>
	</article>
<?php
	break;
endswitch; // end comment_type check
