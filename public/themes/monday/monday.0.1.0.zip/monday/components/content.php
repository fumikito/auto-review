<?php
/*
 * Default entry
 */

?>
<article <?php post_class(); ?>>

<header>
<?php
	
	if ( has_post_thumbnail() ) {

		if ( is_singular() ) {
			printf( '<div class="entry-image"><a href="%s">%s</a></div>',
				wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' )[0],
				get_the_post_thumbnail()
			);
			
		} else {
			printf( '<div class="entry-image"><a href="%s">%s</a></div>',
				get_permalink(),
				get_the_post_thumbnail()
			);
			
		}
	
	}
	
	if ( is_singular() ) {
		the_title( '<h1 class="entry-title">', '</h1>' );
		
	} else {
		the_title( '<h1 class="entry-title"><a href="' . get_permalink() . '" rel="bookmark">', '</a></h1>' );
		
	}
	
?>
</header>

<footer class="entry-meta">
<?php

if ( in_array( get_post_type(), array('post') ) ) {

	if ( is_sticky() ) {
		echo '<span class="entry-sticky">' . __( 'Sticky', 'monday' ) . '</span>';
	
	}

	if ( $author = get_the_author() ) {
		echo '<span class="entry-author">' . sprintf( __( 'By %s', 'monday' ), $author ) . '</span>';
	
	}
	
	the_date( get_option('date_format'), '<span class="entry-date">', '</span>' );
	
	if ( post_type_supports( get_post_type(), 'comments') ) {
		
		echo '<span class="entry-comments">';
		comments_number(
			__( 'No responses', 'monday' ),
			__( 'One response', 'monday' ),
			__( '% responses', 'monday' )
		);
		echo '</span>';
		
	}

}
	
?>
</footer>

<?php

// Show the manual excerpt on single pages

global $post;

if ( apply_filters( 'monday_show_post_excerpt', is_singular() && ! empty( $post->post_excerpt ) ) ) {
	printf( '<div class="entry-excerpt">%s</div>', get_the_excerpt() );
}

?>


<div class="entry-content">
<?php
	the_content( __( 'Continue reading &raquo;', 'monday' ) );
	
	if ( is_singular() ) {
		edit_post_link( __( '(Edit this)', 'monday' ), '<p class="edit-link">', '</p>' );
	}
	
	wp_link_pages( array(
		'before'           => '<p class="pages">' . __( 'Pages:', 'monday' ) . ' ',
		'after'            => '</p>',
		'next_or_number'   => 'number',
		'nextpagelink'     => __( 'Next page', 'monday' ),
		'previouspagelink' => __( 'Previous page', 'monday' ),
	) );
	
?>
</div>

<footer class="entry-footer">
<?php
	
	// Show the taxonomies for this post
	if ( apply_filters( 'monday_show_post_terms', is_single( array( 'post' ) ) ) ) {
		
		if ( $cats = get_the_category_list( __( ', ', 'monday' ) ) ) {
			echo '<p class="entry-cats"><span>' . __( 'Categories: ', 'monday' ) . '</span>' . $cats . '</p>';
			
		}
		
		echo get_the_tag_list( '<p class="entry-tags"><span>' . __( 'Tags: ', 'monday' ) . '</span>', __( ', ', 'monday' ), '</p>' );

	} elseif ( is_singular() && get_the_taxonomies() ) {
		the_taxonomies( array(
	    'before' => '<p class="entry-terms">',
	    'after' => '</p>',
		) );
		
	}
	
	// Show the social links
	if ( apply_filters( 'monday_show_post_social', false && is_singular( array( 'post' ) ) ) ) {
		get_template_part( 'components/social' );
		
	}
	
?>
</footer>

</article>
