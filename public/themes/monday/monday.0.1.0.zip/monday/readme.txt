Monday WordPress theme readme

A clean and responsive theme to to start building your website on. Monday theme will look great on any device and is designed mobile-first. The whitespace will draw the visitor's attention to your media and text content. You can add your own logo and header image and you can customize the footer text. Monday theme is clean, lightweight and fast, and offers 4 navigation areas, plus 3 widget areas and a full width page template.

You can contact the author via wordpress.org.

Changelog
=========

0.1.0 - initial release