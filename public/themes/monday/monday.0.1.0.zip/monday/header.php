<?php
/*
 * Header template
 */

get_template_part( 'components/head' );

?>

<?php
	get_template_part( 'components/skip-links' );	
?>

<header class="site-header">

<?php
	get_template_part( 'components/header-nav' );
?>

<div id="header" role="banner">
<?php
	get_template_part( 'components/header-logo' );
	get_template_part( 'components/header-text' );
	get_template_part( 'components/nav', 'primary' );
?>
</div>

<?php
	get_template_part( 'components/header-widgets' );
	get_template_part( 'components/header-image' );
	get_template_part( 'components/nav', 'secondary' );
?>

</header>

<?php
	do_action( 'monday_content_wrap_before' );
	
?>
