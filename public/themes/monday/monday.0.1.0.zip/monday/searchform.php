<?php
/*
 * Search form template
 */

?>

<form method="get" class="searchform" role="search" action="<?php echo home_url('/'); ?>">
	<input type="search" id="s" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" placeholder="<?php echo esc_attr( _ex( 'Search ...', 'search placeholder', 'monday' ) ); ?>" title="<?php echo esc_attr( _ex( 'Type something and press enter to start searching.', 'search hint', 'monday' ) ); ?>" />
	<input type="submit" class="submit" value="<?php echo esc_attr( _ex( 'Search', 'search button text', 'monday' ) ); ?>" />
</form>